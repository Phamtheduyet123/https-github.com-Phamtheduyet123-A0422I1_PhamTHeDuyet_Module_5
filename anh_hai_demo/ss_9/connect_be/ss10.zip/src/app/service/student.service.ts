import {Injectable} from '@angular/core';
import {Student} from "../model/student";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable()
export class StudentService {
  URL = "http://localhost:3000/students";
  students: Student[] = [];

  constructor(private httpClient: HttpClient) {
    this.students.push({id: 1, name: 'HaiTT', point: 10, dateOfBirth: '1998-01-01'});
    this.students.push({id: 2, name: 'TrungDP', point: 9, dateOfBirth: '1998-01-01'});
    this.students.push({id: 3, name: 'TrungDC', point: 8, dateOfBirth: '1998-01-01'});
    this.students.push({id: 4, name: 'ChanhTV', point: 5, dateOfBirth: '1998-01-01'});
    this.students.push({id: 5, name: 'TrungTVH', point: 7, dateOfBirth: '1998-01-01'});
  }

  findAll(): Observable<any> {

    return this.httpClient.get(this.URL);
  }

  save(value: any) {
    return this.httpClient.post(this.URL, value);
  }

  findById(id: string | null) {
    return this.httpClient.get(this.URL + "/" + id);
  }
}
