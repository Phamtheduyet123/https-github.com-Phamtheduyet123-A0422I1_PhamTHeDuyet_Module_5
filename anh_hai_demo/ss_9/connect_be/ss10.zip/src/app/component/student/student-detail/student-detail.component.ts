import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {Student} from '../../../model/student';
import {ActivatedRoute} from "@angular/router";
import {StudentService} from "../../../service/student.service";

@Component({
  selector: 'app-student-detail',
  templateUrl: './student-detail.component.html',
  styleUrls: ['./student-detail.component.css']
})
export class StudentDetailComponent implements OnInit, OnChanges {
  student: Student | null = {};

  constructor(private activatedRoute: ActivatedRoute, private studentService: StudentService) {
    this.activatedRoute.paramMap.subscribe(data => {
      const id = data.get("id");
    this.studentService.findById(id).subscribe(data => {
      this.student = data;
    });
    })
  }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log(changes);
  }
}
