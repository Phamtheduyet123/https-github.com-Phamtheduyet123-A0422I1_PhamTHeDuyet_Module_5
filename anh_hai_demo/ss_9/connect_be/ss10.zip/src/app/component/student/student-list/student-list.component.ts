import {Component, OnInit} from '@angular/core';
import {Student} from '../../../model/student';
import {StudentService} from "../../../service/student.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {
  students: Student[] = [];
  student: Student = {};

  constructor(private studentService: StudentService,
              private router: Router) {
    this.studentService.findAll().subscribe((data: Student[]) => {
        this.students = data;
      console.log(this.students)
    });

  }

  ngOnInit(): void {
  }

  detailStudent(id: number | undefined) {
    this.router.navigate(["/student/detail", id]);
  }
}
