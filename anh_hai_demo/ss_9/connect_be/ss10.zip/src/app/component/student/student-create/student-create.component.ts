import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {Student} from '../../../model/student';
import {AbstractControl, FormControl, FormGroup, NgForm, Validators} from "@angular/forms";
import {StudentService} from "../../../service/student.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-student-create',
  templateUrl: './student-create.component.html',
  styleUrls: ['./student-create.component.css']
})
export class StudentCreateComponent implements OnInit {
  studentCreate: Student = {};
  isSubmit = false;

  studentFormCreate: FormGroup;

  @Output()
  submitCreateStudent = new EventEmitter();

  constructor(private studentService: StudentService, private router: Router) {
    this.studentFormCreate = new FormGroup({
      id: new FormControl("", [Validators.required, Validators.min(0)]),
      name: new FormControl("", [Validators.minLength(5)]),
      dateOfBirth: new FormControl(),
      point: new FormControl("", [this.validateCustomPoint])
    }, [])
  }

  validateCustomPoint(control: AbstractControl) {
    let point = control.value;
    if (point < 0) {
      return {'invalid0': true}
    }
    return null;
  }

  ngOnInit(): void {
  }

  createStudent() {
    this.submitCreateStudent.emit(this.studentCreate)
    console.log(this.studentCreate);
    this.studentCreate = {};
  }

  createStudentWithTemplate(registerForm: NgForm) {
    console.log(registerForm)
    if (registerForm.valid) {
      this.submitCreateStudent.emit(registerForm.value)
    }

  }

  submitStudentWithReactive() {
    this.studentService.save(this.studentFormCreate.value).subscribe(data => {
        this.router.navigateByUrl("")
      }, error => {
      },
      () => {
      });

  }
}
